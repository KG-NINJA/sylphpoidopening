def run_animation(width=640, height=480, record=False):
    print(f"[MockRun] Animation running at {width}x{height}, record={record}")
    # TODO: implement wireframe animation here
