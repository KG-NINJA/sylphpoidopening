# Placeholder for geometry (fighter, carrier)
