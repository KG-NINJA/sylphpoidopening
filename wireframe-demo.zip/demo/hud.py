# Placeholder for HUD / font rendering
